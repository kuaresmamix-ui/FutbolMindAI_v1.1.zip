# FutbolMind AI Backend

Backend mínimo para proteger o token da API.

## Configuração
1. Instalar Node.js 20+.
2. Copiar `.env.example` para `.env`.
3. Colocar o token Sportmonks em `SPORTMONKS_TOKEN`.
4. `npm install`
5. `npm start`

Endpoints:
- `GET /api/health`
- `GET /api/leagues`
- `GET /api/fixtures/:id`

O token fica apenas no servidor. Nunca o colocar no APK ou no Git.
