# Sincronização automática

O script `sync.js` avalia previsões pendentes e guarda o resultado real.

## Linux cron — exemplo
Executar a cada hora:

`0 * * * * cd /caminho/FutbolMindAI/backend && /usr/bin/node sync.js >> sync.log 2>&1`

## Windows Task Scheduler
Criar uma tarefa que execute:
- Programa: `node`
- Argumentos: `C:\caminho\FutbolMindAI\backend\sync.js`
- Repetição: a cada 1 hora

## Produção
Preferir um scheduler do próprio servidor/cloud. Não expor `sync.js` diretamente à internet.
