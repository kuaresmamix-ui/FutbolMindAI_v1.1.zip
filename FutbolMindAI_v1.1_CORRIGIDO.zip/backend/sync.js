import dotenv from "dotenv";
import Database from "better-sqlite3";

dotenv.config();

const TOKEN = process.env.SPORTMONKS_TOKEN;
const db = new Database(process.env.DB_FILE || "futbolmind.db");

if (!TOKEN) {
  console.error("SPORTMONKS_TOKEN não configurado.");
  process.exit(1);
}

async function sm(path, params = {}) {
  const url = new URL(`https://api.sportmonks.com/v3/football/${path}`);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const res = await fetch(url, { headers: { Authorization: TOKEN } });
  if (!res.ok) throw new Error(`Sportmonks ${res.status}: ${await res.text()}`);
  return res.json();
}

db.exec(`
CREATE TABLE IF NOT EXISTS sync_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  checked INTEGER DEFAULT 0,
  evaluated INTEGER DEFAULT 0,
  status TEXT NOT NULL,
  message TEXT
);
`);

async function run() {
  const started = new Date().toISOString();
  const run = db.prepare(
    "INSERT INTO sync_runs (started_at,status) VALUES (?,?)"
  ).run(started, "RUNNING");

  let checked = 0;
  let evaluated = 0;

  try {
    const pending = db.prepare(`
      SELECT * FROM predictions
      WHERE evaluated_at IS NULL
      ORDER BY id ASC LIMIT 100
    `).all();

    checked = pending.length;

    for (const p of pending) {
      try {
        const data = await sm(`fixtures/${p.fixture_id}`, {
          include: "participants;state;scores"
        });
        const f = data.data;
        const state = (f?.state?.name || "").toLowerCase();

        const finished = [
          "ft", "finished", "after penalties", "aet",
          "full time", "fulltime"
        ].some(x => state.includes(x));

        if (!finished) continue;

        const scores = f?.scores || [];
        const current = scores.filter(s => s.description === "CURRENT");

        // Prefer participant IDs to avoid assuming array order.
        const participants = f?.participants || [];
        const homeParticipant = participants.find(x => x.meta?.location === "home");
        const awayParticipant = participants.find(x => x.meta?.location === "away");

        const homeScore = current.find(x =>
          String(x.participant_id) === String(homeParticipant?.id)
        );
        const awayScore = current.find(x =>
          String(x.participant_id) === String(awayParticipant?.id)
        );

        const hg = Number(homeScore?.score?.goals);
        const ag = Number(awayScore?.score?.goals);

        if (!Number.isInteger(hg) || !Number.isInteger(ag)) continue;

        const result = hg > ag ? "HOME" : hg < ag ? "AWAY" : "DRAW";

        db.prepare(`
          UPDATE predictions
          SET result=?, actual_home_goals=?, actual_away_goals=?, evaluated_at=datetime('now')
          WHERE id=?
        `).run(result, hg, ag, p.id);

        evaluated++;
      } catch (e) {
        console.warn(`Falha fixture ${p.fixture_id}: ${e.message}`);
      }
    }

    db.prepare(`
      UPDATE sync_runs
      SET finished_at=?, checked=?, evaluated=?, status=?, message=?
      WHERE id=?
    `).run(
      new Date().toISOString(), checked, evaluated, "SUCCESS",
      "Sincronização concluída.", run.lastInsertRowid
    );

    console.log(JSON.stringify({ checked, evaluated, status: "SUCCESS" }));
  } catch (e) {
    db.prepare(`
      UPDATE sync_runs
      SET finished_at=?, checked=?, evaluated=?, status=?, message=?
      WHERE id=?
    `).run(
      new Date().toISOString(), checked, evaluated, "ERROR",
      e.message, run.lastInsertRowid
    );
    console.error(e);
    process.exit(1);
  }
}

run();
