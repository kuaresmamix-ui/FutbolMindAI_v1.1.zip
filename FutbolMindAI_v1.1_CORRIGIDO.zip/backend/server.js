import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import Database from "better-sqlite3";
import { trainAI, latestModel, predictAI, importHistorical } from "./ai-engine.js";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const TOKEN = process.env.SPORTMONKS_TOKEN;
const db = new Database(process.env.DB_FILE || "futbolmind.db");
try { db.exec("ALTER TABLE predictions ADD COLUMN model_version TEXT"); } catch (_) {}

db.exec(`
CREATE TABLE IF NOT EXISTS predictions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fixture_id INTEGER NOT NULL,
  home_team TEXT NOT NULL,
  away_team TEXT NOT NULL,
  home_probability INTEGER NOT NULL,
  draw_probability INTEGER NOT NULL,
  away_probability INTEGER NOT NULL,
  over25_probability INTEGER,
  btts_probability INTEGER,
  predicted_at TEXT NOT NULL,
  result TEXT,
  actual_home_goals INTEGER,
  actual_away_goals INTEGER,
  evaluated_at TEXT,
  model_version TEXT
);
CREATE INDEX IF NOT EXISTS idx_predictions_fixture ON predictions(fixture_id);
`);

async function sm(path, params = {}) {
  if (!TOKEN) throw new Error("SPORTMONKS_TOKEN não configurado");
  const url = new URL(`https://api.sportmonks.com/v3/football/${path}`);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const res = await fetch(url, { headers: { Authorization: TOKEN } });
  if (!res.ok) throw new Error(`Sportmonks ${res.status}: ${await res.text()}`);
  return res.json();
}

app.get("/api/health", (_, res) =>
  res.json({ ok: true, app: "FutbolMind AI", version: "1.1" })
);

app.get("/api/leagues", async (_, res) => {
  try { res.json(await sm("leagues", { per_page: "100" })); }
  catch (e) { res.status(502).json({ error: e.message }); }
});

app.get("/api/leagues/:leagueId/teams", async (req, res) => {
  try { res.json(await sm(`teams/season/${req.params.leagueId}`, { per_page: "100" })); }
  catch (e) { res.status(502).json({ error: e.message }); }
});

app.get("/api/fixtures", async (req, res) => {
  try {
    const params = { per_page: req.query.per_page || "100" };
    if (req.query.date) params.date = req.query.date;
    res.json(await sm("fixtures", params));
  } catch (e) { res.status(502).json({ error: e.message }); }
});

app.get("/api/fixtures/:id", async (req, res) => {
  try {
    res.json(await sm(`fixtures/${req.params.id}`, {
      include: "participants;league;venue;state;scores;events.type;events.player;statistics;lineups.player;lineups.details"
    }));
  } catch (e) { res.status(502).json({ error: e.message }); }
});

app.post("/api/predictions", (req, res) => {
  try {
    const p = req.body;
    const result = db.prepare(`
      INSERT INTO predictions
      (fixture_id, home_team, away_team, home_probability, draw_probability,
       away_probability, over25_probability, btts_probability, predicted_at, model_version)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), ?)
    `).run(
      p.fixture_id, p.home_team, p.away_team,
      p.home_probability, p.draw_probability, p.away_probability,
      p.over25_probability ?? null, p.btts_probability ?? null, p.model_version ?? null
    );
    res.json({ id: result.lastInsertRowid });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.get("/api/predictions", (req, res) => {
  const limit = Math.min(Number(req.query.limit || 100), 500);
  res.json(db.prepare("SELECT * FROM predictions ORDER BY id DESC LIMIT ?").all(limit));
});

// Avalia uma previsão com o resultado final.
// Também calcula automaticamente Over 2.5 e BTTS.
app.post("/api/predictions/:id/evaluate", (req, res) => {
  try {
    const p = db.prepare("SELECT * FROM predictions WHERE id = ?").get(req.params.id);
    if (!p) return res.status(404).json({ error: "Previsão não encontrada" });

    const hg = Number(req.body.home_goals);
    const ag = Number(req.body.away_goals);
    if (!Number.isInteger(hg) || !Number.isInteger(ag) || hg < 0 || ag < 0) {
      return res.status(400).json({ error: "Golos inválidos" });
    }

    const result = hg > ag ? "HOME" : hg < ag ? "AWAY" : "DRAW";
    const over25Actual = (hg + ag) > 2.5;
    const bttsActual = hg > 0 && ag > 0;

    const max1x2 = Math.max(p.home_probability, p.draw_probability, p.away_probability);
    const predicted1x2 =
      max1x2 === p.home_probability ? "HOME" :
      max1x2 === p.away_probability ? "AWAY" : "DRAW";

    const over25Predicted = p.over25_probability == null ? null : p.over25_probability >= 50;
    const bttsPredicted = p.btts_probability == null ? null : p.btts_probability >= 50;

    db.prepare(`
      UPDATE predictions
      SET result=?, actual_home_goals=?, actual_away_goals=?, evaluated_at=datetime('now')
      WHERE id=?
    `).run(result, hg, ag, p.id);

    res.json({
      fixture_id: p.fixture_id,
      result,
      score: `${hg}-${ag}`,
      correct1x2: predicted1x2 === result,
      correctOver25: over25Predicted == null ? null : over25Predicted === over25Actual,
      correctBTTS: bttsPredicted == null ? null : bttsPredicted === bttsActual
    });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

// Avaliação automática: percorre previsões não avaliadas,
// consulta o resultado final e preenche o histórico.
app.post("/api/predictions/auto-evaluate", async (_, res) => {
  try {
    const pending = db.prepare(`
      SELECT * FROM predictions
      WHERE evaluated_at IS NULL
      ORDER BY id ASC LIMIT 50
    `).all();

    let evaluated = 0;
    for (const p of pending) {
      try {
        const data = await sm(`fixtures/${p.fixture_id}`, { include: "scores;state" });
        const f = data.data;
        const state = f?.state?.name?.toLowerCase() || "";
        const finished = ["ft", "finished", "after penalties", "aet"].some(x => state.includes(x));
        if (!finished) continue;

        const scores = f?.scores || [];
        const homeScore = scores.find(x => String(x.participant_id) === String(f.participants?.[0]?.id) && x.description === "CURRENT");
        const awayScore = scores.find(x => String(x.participant_id) === String(f.participants?.[1]?.id) && x.description === "CURRENT");
        if (!homeScore || !awayScore) continue;

        const hg = Number(homeScore.score?.goals);
        const ag = Number(awayScore.score?.goals);
        if (!Number.isInteger(hg) || !Number.isInteger(ag)) continue;

        const result = hg > ag ? "HOME" : hg < ag ? "AWAY" : "DRAW";
        db.prepare(`
          UPDATE predictions
          SET result=?, actual_home_goals=?, actual_away_goals=?, evaluated_at=datetime('now')
          WHERE id=?
        `).run(result, hg, ag, p.id);
        evaluated++;
      } catch (_) {}
    }

    res.json({ checked: pending.length, evaluated });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get("/api/dashboard", (_, res) => {
  const rows = db.prepare("SELECT * FROM predictions WHERE result IS NOT NULL").all();

  const metric = (key) => {
    const valid = rows.filter(r => r[key] !== null && r[key] !== undefined);
    if (!valid.length) return { evaluated: 0, correct: 0, accuracy: null };
    let correct = 0;
    for (const r of valid) {
      const predicted = r[key] >= 50;
      const actual = key === "over25_probability"
        ? (r.actual_home_goals + r.actual_away_goals > 2)
        : (r.actual_home_goals > 0 && r.actual_away_goals > 0);
      if (predicted === actual) correct++;
    }
    return { evaluated: valid.length, correct, accuracy: Math.round(correct / valid.length * 1000) / 10 };
  };

  let correct1x2 = 0;
  for (const r of rows) {
    const max = Math.max(r.home_probability, r.draw_probability, r.away_probability);
    const pred = max === r.home_probability ? "HOME" : max === r.away_probability ? "AWAY" : "DRAW";
    if (pred === r.result) correct1x2++;
  }

  res.json({
    evaluated: rows.length,
    overall: { evaluated: rows.length, correct: correct1x2, accuracy: rows.length ? Math.round(correct1x2 / rows.length * 1000) / 10 : null },
    oneX2: {
      evaluated: rows.length,
      correct: correct1x2,
      accuracy: rows.length ? Math.round(correct1x2 / rows.length * 1000) / 10 : null
    },
    over25: metric("over25_probability"),
    btts: metric("btts_probability")
  });
});


app.get("/api/ai/status", (_, res) => {
  try {
    const model = latestModel();
    const historical = db.prepare("SELECT COUNT(*) AS n FROM historical_matches").get().n;
    res.json({ trained: !!model, historical_matches: historical, model: model ? { version: model.version, trained_at: model.trained_at, metrics: model.metrics } : null });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/ai/import-history", (req, res) => {
  try {
    if (!Array.isArray(req.body?.matches)) return res.status(400).json({ error: "Envie { matches: [...] }" });
    const imported = importHistorical(req.body.matches);
    res.json({ imported, historical_matches: db.prepare("SELECT COUNT(*) AS n FROM historical_matches").get().n });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.post("/api/ai/train", (_, res) => {
  try { res.json(trainAI()); }
  catch (e) { res.status(400).json({ error: e.message }); }
});

app.get("/api/ai/metrics", (_, res) => {
  try { const m=latestModel(); if(!m) return res.status(404).json({ error: "Nenhum modelo treinado" }); res.json({ version:m.version, trained_at:m.trained_at, metrics:m.metrics }); }
  catch (e) { res.status(500).json({ error:e.message }); }
});

app.get("/api/ai/predict", (req, res) => {
  try {
    const home=Number(req.query.home_team_id), away=Number(req.query.away_team_id);
    if(!Number.isInteger(home)||!Number.isInteger(away)) return res.status(400).json({error:"home_team_id e away_team_id são obrigatórios"});
    res.json(predictAI(home,away));
  } catch(e) { res.status(400).json({error:e.message}); }
});

app.post("/api/ai/predict-and-save", (req, res) => {
  try {
    const homeId=Number(req.body?.home_team_id), awayId=Number(req.body?.away_team_id);
    if(!Number.isInteger(homeId)||!Number.isInteger(awayId)) return res.status(400).json({error:"home_team_id e away_team_id são obrigatórios"});
    const prediction=predictAI(homeId,awayId);
    const p=req.body;
    const saved=db.prepare(`INSERT INTO predictions(fixture_id,home_team,away_team,home_probability,draw_probability,away_probability,over25_probability,btts_probability,predicted_at,model_version) VALUES(?,?,?,?,?,?,?,?,datetime('now'),?)`).run(
      Number(p.fixture_id||0), p.home_team||String(homeId), p.away_team||String(awayId),
      Math.round(prediction.probabilities.home*100),Math.round(prediction.probabilities.draw*100),Math.round(prediction.probabilities.away*100),
      Math.round(prediction.probabilities.over25*100),Math.round(prediction.probabilities.btts*100),prediction.model_version
    );
    res.json({id:saved.lastInsertRowid,...prediction});
  } catch(e) { res.status(400).json({error:e.message}); }
});

app.get("/api/sync/history", (_, res) => {
  const rows = db.prepare(`
    SELECT * FROM sync_runs ORDER BY id DESC LIMIT 20
  `).all();
  res.json(rows);
});

app.listen(PORT, () => console.log(`FutbolMind backend em http://localhost:${PORT}`));
