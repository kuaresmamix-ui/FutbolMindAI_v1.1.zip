import Database from "better-sqlite3";

const db = new Database(process.env.DB_FILE || "futbolmind.db");

db.exec(`
CREATE TABLE IF NOT EXISTS historical_matches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fixture_id INTEGER UNIQUE,
  league_id INTEGER,
  season_id INTEGER,
  starting_at TEXT NOT NULL,
  home_team_id INTEGER NOT NULL,
  home_team TEXT NOT NULL,
  away_team_id INTEGER NOT NULL,
  away_team TEXT NOT NULL,
  home_goals INTEGER NOT NULL,
  away_goals INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_hist_date ON historical_matches(starting_at);
CREATE INDEX IF NOT EXISTS idx_hist_home ON historical_matches(home_team_id, starting_at);
CREATE INDEX IF NOT EXISTS idx_hist_away ON historical_matches(away_team_id, starting_at);
CREATE TABLE IF NOT EXISTS ai_models (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  version TEXT NOT NULL UNIQUE,
  trained_at TEXT NOT NULL,
  train_matches INTEGER NOT NULL,
  test_matches INTEGER NOT NULL,
  metrics_json TEXT NOT NULL,
  model_json TEXT NOT NULL
);
`);

const clamp = (x, lo = 1e-6, hi = 1 - 1e-6) => Math.max(lo, Math.min(hi, x));
const sigmoid = x => 1 / (1 + Math.exp(-Math.max(-35, Math.min(35, x))));
const softmax = z => {
  const m = Math.max(...z);
  const e = z.map(v => Math.exp(Math.max(-35, Math.min(35, v - m))));
  const s = e.reduce((a,b) => a+b, 0) || 1;
  return e.map(v => v/s);
};

function statMap(rows) {
  const map = new Map();
  const ensure = id => {
    if (!map.has(id)) map.set(id, { n:0, gf:0, ga:0, pts:0, homeN:0, homeGF:0, homeGA:0, awayN:0, awayGF:0, awayGA:0, recent:[] });
    return map.get(id);
  };
  const add = (id, gf, ga, home) => {
    const s = ensure(id);
    s.n++; s.gf += gf; s.ga += ga; s.pts += gf > ga ? 3 : gf === ga ? 1 : 0;
    if (home) { s.homeN++; s.homeGF += gf; s.homeGA += ga; }
    else { s.awayN++; s.awayGF += gf; s.awayGA += ga; }
    s.recent.push(gf > ga ? 3 : gf === ga ? 1 : 0);
    if (s.recent.length > 5) s.recent.shift();
  };
  for (const r of rows) {
    add(r.home_team_id, r.home_goals, r.away_goals, true);
    add(r.away_team_id, r.away_goals, r.home_goals, false);
  }
  return { map, add };
}

function avg(x, n, fallback) { return n ? x/n : fallback; }
function featuresFor(home, away, stats, leagueAvgGoals = 1.35) {
  const h = stats.get(home), a = stats.get(away);
  const hs = h || {n:0,gf:0,ga:0,pts:0,homeN:0,homeGF:0,homeGA:0,recent:[]};
  const as = a || {n:0,gf:0,ga:0,pts:0,awayN:0,awayGF:0,awayGA:0,recent:[]};
  const hgf = avg(hs.homeGF, hs.homeN, leagueAvgGoals), hga = avg(hs.homeGA, hs.homeN, leagueAvgGoals);
  const agf = avg(as.awayGF, as.awayN, leagueAvgGoals), aga = avg(as.awayGA, as.awayN, leagueAvgGoals);
  const hform = avg(hs.recent.reduce((x,y)=>x+y,0), hs.recent.length, 1.5) / 3;
  const aform = avg(as.recent.reduce((x,y)=>x+y,0), as.recent.length, 1.5) / 3;
  return [
    clamp((hgf - agf) / 3, -1, 1), clamp((aga - hga) / 3, -1, 1),
    hform - aform,
    avg(hs.gf, hs.n, leagueAvgGoals) - avg(as.gf, as.n, leagueAvgGoals),
    avg(hs.ga, hs.n, leagueAvgGoals) - avg(as.ga, as.n, leagueAvgGoals),
    Math.min(hs.n, 10) / 10, Math.min(as.n, 10) / 10,
    1
  ];
}

function trainBinary(X, y, opts={}) {
  const lr = opts.lr ?? 0.08, epochs = opts.epochs ?? 900, l2 = opts.l2 ?? 0.01;
  const w = Array(X[0].length).fill(0), mean = Array(w.length).fill(0), sd = Array(w.length).fill(1);
  for (let j=0;j<w.length;j++) { mean[j]=X.reduce((s,r)=>s+r[j],0)/X.length; const v=X.reduce((s,r)=>s+(r[j]-mean[j])**2,0)/X.length; sd[j]=Math.sqrt(v)||1; }
  const Z=X.map(r=>r.map((v,j)=>(v-mean[j])/sd[j]));
  for(let ep=0;ep<epochs;ep++){
    const g=Array(w.length).fill(0);
    for(let i=0;i<Z.length;i++){ const p=sigmoid(Z[i].reduce((s,v,j)=>s+v*w[j],0)); const e=p-y[i]; for(let j=0;j<w.length;j++) g[j]+=e*Z[i][j]; }
    for(let j=0;j<w.length;j++) w[j]-=lr*(g[j]/Z.length+l2*w[j]);
  }
  return {w,mean,sd,predict:r=>sigmoid(r.reduce((s,v,j)=>s+((v-mean[j])/sd[j])*w[j],0))};
}

function trainMulticlass(X, y, opts={}) {
  const lr=opts.lr??0.06, epochs=opts.epochs??1100, l2=opts.l2??0.01, k=3, d=X[0].length;
  const mean=Array(d).fill(0), sd=Array(d).fill(1);
  for(let j=0;j<d;j++){mean[j]=X.reduce((s,r)=>s+r[j],0)/X.length; const v=X.reduce((s,r)=>s+(r[j]-mean[j])**2,0)/X.length; sd[j]=Math.sqrt(v)||1;}
  const Z=X.map(r=>r.map((v,j)=>(v-mean[j])/sd[j]));
  const W=Array.from({length:k},()=>Array(d).fill(0));
  for(let ep=0;ep<epochs;ep++){
    const G=Array.from({length:k},()=>Array(d).fill(0));
    for(let i=0;i<Z.length;i++){
      const p=softmax(W.map(row=>row.reduce((s,v,j)=>s+v*Z[i][j],0)));
      for(let c=0;c<k;c++){const e=p[c]-(y[i]===c?1:0);for(let j=0;j<d;j++)G[c][j]+=e*Z[i][j];}
    }
    for(let c=0;c<k;c++)for(let j=0;j<d;j++)W[c][j]-=lr*(G[c][j]/Z.length+l2*W[c][j]);
  }
  return {W,mean,sd,predict:r=>softmax(W.map(row=>row.reduce((s,v,j)=>s+v*((r[j]-mean[j])/sd[j]),0)))};
}

function logLossMulti(model, X, y) { let s=0; for(let i=0;i<X.length;i++) s-=Math.log(clamp(model.predict(X[i])[y[i]])); return s/X.length; }
function accuracyMulti(model, X, y) { let c=0; for(let i=0;i<X.length;i++){const p=model.predict(X[i]);if(p.indexOf(Math.max(...p))===y[i])c++;}return c/X.length; }
function brierBinary(model, X, y) { let s=0; for(let i=0;i<X.length;i++){const p=model.predict(X[i]);s+=(p-y[i])**2;}return s/X.length; }

export function trainAI() {
  const rows=db.prepare(`SELECT * FROM historical_matches ORDER BY datetime(starting_at) ASC, id ASC`).all();
  if(rows.length<60) throw new Error(`Dados insuficientes: são necessários pelo menos 60 jogos históricos; existem ${rows.length}.`);
  const stats=statMap([]), X=[], y1=[], yO=[], yB=[], metas=[];
  const split=Math.max(30, Math.floor(rows.length*0.8));
  for(let i=0;i<rows.length;i++){
    const r=rows[i];
    const prior=featuresFor(r.home_team_id,r.away_team_id,stats.map,1.35);
    X.push(prior); y1.push(r.home_goals>r.away_goals?0:r.home_goals<r.away_goals?2:1); yO.push(r.home_goals+r.away_goals>2?1:0); yB.push(r.home_goals>0&&r.away_goals>0?1:0); metas.push(r);
    stats.add(r.home_team_id,r.home_goals,r.away_goals,true); stats.add(r.away_team_id,r.away_goals,r.home_goals,false);
  }
  const trainX=X.slice(0,split), testX=X.slice(split);
  const m1=trainMulticlass(trainX,y1.slice(0,split));
  const mo=trainBinary(trainX,yO.slice(0,split));
  const mb=trainBinary(trainX,yB.slice(0,split));
  const metrics={
    train_matches:split,test_matches:rows.length-split,
    test_accuracy_1x2:accuracyMulti(m1,testX,y1.slice(split)),
    test_logloss_1x2:logLossMulti(m1,testX,y1.slice(split)),
    test_brier_over25:brierBinary(mo,testX,yO.slice(split)),
    test_brier_btts:brierBinary(mb,testX,yB.slice(split)),
    temporal_split:true,data_leakage_protection:true
  };
  const version=`fm-${new Date().toISOString().replace(/[-:.TZ]/g,'').slice(0,14)}`;
  const model={version,oneX2:m1,over25:mo,btts:mb,trainedRows:rows.length,trainedAt:new Date().toISOString()};
  db.prepare(`INSERT INTO ai_models(version,trained_at,train_matches,test_matches,metrics_json,model_json) VALUES(?,?,?,?,?,?)`).run(version,model.trainedAt,split,rows.length-split,JSON.stringify(metrics),JSON.stringify(model));
  return {version,metrics};
}

export function latestModel(){
  const row=db.prepare(`SELECT * FROM ai_models ORDER BY id DESC LIMIT 1`).get();
  return row ? {version:row.version,trained_at:row.trained_at,metrics:JSON.parse(row.metrics_json),model:JSON.parse(row.model_json)} : null;
}

export function predictAI(homeTeamId, awayTeamId){
  const latest=latestModel(); if(!latest) throw new Error("A IA ainda não foi treinada. Importe histórico e execute o treino.");
  const rows=db.prepare(`SELECT * FROM historical_matches ORDER BY datetime(starting_at) ASC, id ASC`).all();
  const stats=statMap(rows); const x=featuresFor(Number(homeTeamId),Number(awayTeamId),stats.map,1.35);
  const one=latest.model.oneX2.predict(x), over=latest.model.over25.predict(x), btts=latest.model.btts.predict(x);
  const labels=["HOME","DRAW","AWAY"]; const best=labels[one.indexOf(Math.max(...one))];
  return {model_version:latest.version, prediction:best, probabilities:{home:one[0],draw:one[1],away:one[2],over25:over,btts:btts},features:x};
}

export function importHistorical(matches=[]){
  const insert=db.prepare(`INSERT OR REPLACE INTO historical_matches(fixture_id,league_id,season_id,starting_at,home_team_id,home_team,away_team_id,away_team,home_goals,away_goals) VALUES(?,?,?,?,?,?,?,?,?,?)`);
  const tx=db.transaction(items=>{let n=0;for(const m of items){if(!m.starting_at||m.home_team_id==null||m.away_team_id==null)continue;insert.run(m.fixture_id??null,m.league_id??null,m.season_id??null,m.starting_at,m.home_team_id,m.home_team||String(m.home_team_id),m.away_team_id,m.away_team||String(m.away_team_id),Number(m.home_goals),Number(m.away_goals));n++;}return n;});
  return tx(matches);
}
