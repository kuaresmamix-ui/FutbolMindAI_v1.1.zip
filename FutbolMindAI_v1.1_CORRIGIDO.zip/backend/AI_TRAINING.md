# Treino da IA — FutbolMind AI

## Fluxo
1. Recolher jogos históricos reais.
2. Importar para `historical_matches` através de `POST /api/ai/import-history`.
3. Treinar com `POST /api/ai/train`.
4. O motor ordena por data e constrói as features de cada jogo usando apenas jogos anteriores.
5. Os últimos 20% dos jogos ficam como teste temporal.
6. O modelo guardado recebe uma versão própria.
7. `GET /api/ai/predict` usa o último modelo treinado.

## Porque isto é IA
O projeto agora usa aprendizagem supervisionada: os parâmetros do modelo são aprendidos a partir de resultados históricos. Não são probabilidades escritas manualmente para cada equipa.

## Features atuais
- Força ofensiva recente casa/fora.
- Força defensiva recente casa/fora.
- Forma dos últimos jogos.
- Médias históricas de golos marcados/sofridos.
- Quantidade de jogos disponíveis para cada equipa.
- Diferenças casa vs. fora.

## Modelos
- 1X2: regressão logística multinomial (softmax) com regularização L2.
- Over 2.5: regressão logística binária.
- BTTS: regressão logística binária.

## Avaliação
O treino não deve ser avaliado misturando passado e futuro. A divisão temporal é deliberada para reduzir data leakage. São calculados accuracy e log loss para 1X2 e Brier score para os modelos binários.

## Evolução futura
Depois de ligar o histórico real do fornecedor, podemos adicionar xG, força do adversário, descanso, sequência casa/fora, lesões/suspensões quando disponíveis e calibração das probabilidades. Uma rede neural só deve ser adicionada se melhorar as métricas fora da amostra; mais complexidade não significa automaticamente melhor IA.
