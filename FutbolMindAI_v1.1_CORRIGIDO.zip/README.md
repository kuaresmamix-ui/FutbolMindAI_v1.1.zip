# FutbolMind AI — v1.1

## 🧠 IA real integrada
A versão 1.1 transforma o projeto num pipeline de Machine Learning/IA, em vez de apenas regras fixas.

### O que entrou
- Motor de IA em JavaScript, sem depender de uma API externa de IA.
- Treino temporal: as características de cada jogo são calculadas apenas com jogos anteriores.
- Proteção contra data leakage.
- Modelo 1X2 multinomial.
- Modelos binários para Over 2.5 e Ambas Marcam.
- Normalização de features e regularização L2.
- Métricas de teste: accuracy 1X2, log loss 1X2 e Brier score para Over 2.5/BTTS.
- Versionamento do modelo treinado.
- Endpoint para importar histórico.
- Endpoint para treinar a IA.
- Endpoint para consultar métricas.
- Endpoint para gerar previsão de um confronto.
- Ecrã Android dedicado à análise da IA.

## Como alimentar a IA
A IA precisa de histórico real. O endpoint `POST /api/ai/import-history` aceita:

```json
{
  "matches": [
    {
      "fixture_id": 1001,
      "league_id": 8,
      "season_id": 100,
      "starting_at": "2025-01-10T20:00:00Z",
      "home_team_id": 1,
      "home_team": "Alpha FC",
      "away_team_id": 2,
      "away_team": "Beta FC",
      "home_goals": 2,
      "away_goals": 1
    }
  ]
}
```

Existe um exemplo em `backend/ai-import-example.json`.

Depois de importar pelo menos 60 jogos, executar:

```bash
npm run start
```

E em outro terminal:

```bash
curl -X POST http://localhost:3000/api/ai/train
```

## Endpoints IA
- `GET /api/ai/status`
- `POST /api/ai/import-history`
- `POST /api/ai/train`
- `GET /api/ai/metrics`
- `GET /api/ai/predict?home_team_id=1&away_team_id=2`

## Próximo passo recomendado
Ligar o importador diretamente ao histórico real do fornecedor de dados, por liga/época, e depois aumentar o conjunto de features com xG, casa/fora, descanso, força dos adversários e disponibilidade de jogadores quando esses dados estiverem disponíveis. O treino deve continuar temporal para evitar leakage.

A IA deve ser avaliada com amostra suficiente e contra um baseline simples; percentagens de previsão não são garantias de resultados futuros.


## Ficheiro técnico
Consultar `backend/AI_TRAINING.md` para o desenho do motor de IA e o processo de treino.
