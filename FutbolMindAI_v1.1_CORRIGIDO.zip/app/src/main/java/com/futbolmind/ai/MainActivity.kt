package com.futbolmind.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DashboardScreen()
        }
    }
}

@Composable
fun DashboardScreen() {
    var ai by remember { mutableStateOf(false) }

    if (ai) {
        AiScreen()
        return
    }

    val scope = rememberCoroutineScope()
    val client = remember { DashboardClient("http://10.0.2.2:3000") }
    var evaluated by remember { mutableIntStateOf(0) }
    var correct by remember { mutableStateOf<Int?>(null) }
    var accuracy by remember { mutableStateOf<Double?>(null) }
    var status by remember { mutableStateOf("Carrega o desempenho do modelo.") }
    var loading by remember { mutableStateOf(false) }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("⚽ FutbolMind AI") }) }
        ) { padding ->
            Column(
                Modifier.padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("🧠 Dashboard da IA", style = MaterialTheme.typography.headlineSmall)
                Text("Mede a precisão com base apenas em previsões que já foram avaliadas.")

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Precisão 1X2", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            accuracy?.let { "${"%.1f".format(it)}%" } ?: "—",
                            style = MaterialTheme.typography.displaySmall
                        )
                        Text("$correct acertos em $evaluated jogos avaliados")
                    }
                }

                Button(
                    enabled = !loading,
                    onClick = {
                        scope.launch {
                            loading = true
                            status = "A consultar o servidor..."
                            runCatching { client.summary() }
                                .onSuccess {
                                    evaluated = it.evaluated
                                    correct = it.correct
                                    accuracy = it.accuracy
                                    status = "Dados atualizados."
                                }
                                .onFailure {
                                    status = "Ainda sem dados avaliados: ${it.message}"
                                }
                            loading = false
                        }
                    }
                ) {
                    Text(if (loading) "A carregar..." else "Atualizar desempenho")
                }

                Text(status, style = MaterialTheme.typography.bodyMedium)

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Mercados", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        Text("1X2  •  ativo")
                        Text("Over 2.5  •  avaliação automática a ligar")
                        Text("Ambas marcam  •  avaliação automática a ligar")
                    }
                }

                Button(onClick = { ai = true }) {
                    Text("Abrir análise da IA")
                }

                Text(
                    "Nota: uma percentagem de acerto só ganha significado com uma amostra suficiente e comparação adequada; não é garantia de resultados futuros.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
