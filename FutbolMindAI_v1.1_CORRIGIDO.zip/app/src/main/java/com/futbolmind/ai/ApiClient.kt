package com.futbolmind.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

data class ApiLeague(val id: Long, val name: String, val country: String?)
data class ApiTeam(val id: Long, val name: String)
data class ApiFixture(val id: Long, val name: String, val date: String?, val state: String?)

class ApiClient(private val baseUrl: String) {
    private val client = OkHttpClient()

    private suspend fun get(path: String): String = withContext(Dispatchers.IO) {
        val request = Request.Builder().url("$baseUrl$path").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            response.body!!.string()
        }
    }

    suspend fun health(): Boolean {
        return runCatching { get("/api/health"); true }.getOrDefault(false)
    }

    suspend fun leagues(): List<ApiLeague> {
        val root = JSONObject(get("/api/leagues"))
        val data = root.optJSONArray("data") ?: JSONArray()
        return buildList {
            for (i in 0 until data.length()) {
                val item = data.getJSONObject(i)
                add(ApiLeague(
                    item.optLong("id"),
                    item.optString("name"),
                    item.optJSONObject("country")?.optString("name")
                ))
            }
        }
    }

    suspend fun teams(leagueId: Long): List<ApiTeam> {
        val root = JSONObject(get("/api/leagues/$leagueId/teams"))
        val data = root.optJSONArray("data") ?: JSONArray()
        return buildList {
            for (i in 0 until data.length()) {
                val item = data.getJSONObject(i)
                add(ApiTeam(item.optLong("id"), item.optString("name")))
            }
        }
    }

    suspend fun fixtures(date: String? = null): List<ApiFixture> {
        val path = if (date.isNullOrBlank()) "/api/fixtures" else "/api/fixtures?date=$date"
        val root = JSONObject(get(path))
        val data = root.optJSONArray("data") ?: JSONArray()
        return buildList {
            for (i in 0 until data.length()) {
                val item = data.getJSONObject(i)
                add(ApiFixture(
                    item.optLong("id"),
                    item.optString("name"),
                    item.optString("starting_at"),
                    item.optJSONObject("state")?.optString("name")
                ))
            }
        }
    }
}
