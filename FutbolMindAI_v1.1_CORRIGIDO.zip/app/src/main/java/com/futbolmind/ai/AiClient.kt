package com.futbolmind.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

data class AiPrediction(val version: String, val prediction: String, val home: Double, val draw: Double, val away: Double, val over25: Double, val btts: Double)

class AiClient(private val baseUrl: String) {
    private val client = OkHttpClient()
    suspend fun predict(homeId: Long, awayId: Long): AiPrediction = withContext(Dispatchers.IO) {
        val url = "$baseUrl/api/ai/predict?home_team_id=$homeId&away_team_id=$awayId"
        val request = Request.Builder().url(url).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error(JSONObject(response.body!!.string()).optString("error", "Erro da IA"))
            val raw=response.body!!.string()
            val root=JSONObject(raw)
            val p=root.getJSONObject("probabilities")
            AiPrediction(root.optString("model_version"),root.optString("prediction"),p.optDouble("home"),p.optDouble("draw"),p.optDouble("away"),p.optDouble("over25"),p.optDouble("btts"))
        }
    }
}
