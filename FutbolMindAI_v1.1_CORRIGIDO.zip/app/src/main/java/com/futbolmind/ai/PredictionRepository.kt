package com.futbolmind.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

data class PredictionRequest(
    val fixtureId: Long,
    val homeTeam: String,
    val awayTeam: String,
    val home: Int,
    val draw: Int,
    val away: Int,
    val over25: Int,
    val btts: Int
)

class PredictionRepository(private val baseUrl: String) {
    private val client = OkHttpClient()
    private val jsonType = "application/json".toMediaType()

    suspend fun save(p: PredictionRequest): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("fixture_id", p.fixtureId)
            put("home_team", p.homeTeam)
            put("away_team", p.awayTeam)
            put("home_probability", p.home)
            put("draw_probability", p.draw)
            put("away_probability", p.away)
            put("over25_probability", p.over25)
            put("btts_probability", p.btts)
        }.toString().toRequestBody(jsonType)

        val request = Request.Builder()
            .url("$baseUrl/api/predictions")
            .post(body)
            .build()

        client.newCall(request).execute().use { it.isSuccessful }
    }

    suspend fun accuracy(): String = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("$baseUrl/api/predictions/accuracy")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            response.body!!.string()
        }
    }
}
