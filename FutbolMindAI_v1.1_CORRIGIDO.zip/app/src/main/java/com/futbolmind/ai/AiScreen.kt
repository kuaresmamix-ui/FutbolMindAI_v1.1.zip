package com.futbolmind.ai

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun AiScreen() {
    val scope=rememberCoroutineScope(); val client=remember{AiClient("http://10.0.2.2:3000")}
    var home by remember{mutableStateOf("")}; var away by remember{mutableStateOf("")}; var result by remember{mutableStateOf<AiPrediction?>(null)}; var status by remember{mutableStateOf("Introduz os IDs das duas equipas.")}; var loading by remember{mutableStateOf(false)}
    fun pct(v:Double)="%.1f%%".format(Locale.US,v*100)
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("🧠 IA FutbolMind",style=MaterialTheme.typography.headlineSmall)
        Text("O modelo usa histórico anterior ao jogo para calcular probabilidades.")
        OutlinedTextField(home,{home=it},label={Text("ID equipa casa")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(away,{away=it},label={Text("ID equipa fora")},modifier=Modifier.fillMaxWidth())
        Button(enabled=!loading,onClick={scope.launch{loading=true;status="A IA está a calcular...";runCatching{client.predict(home.toLong(),away.toLong())}.onSuccess{result=it;status="Previsão calculada."}.onFailure{status=it.message?:"Erro"};loading=false}}){Text(if(loading)"A calcular..." else "Analisar com IA")}
        Text(status)
        result?.let{r->
            Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
                Text("Modelo ${r.version}",style=MaterialTheme.typography.labelMedium)
                Text("Previsão: ${r.prediction}",style=MaterialTheme.typography.titleLarge)
                Text("Casa ${pct(r.home)}   •   Empate ${pct(r.draw)}   •   Fora ${pct(r.away)}")
                Text("Over 2.5: ${pct(r.over25)}")
                Text("Ambas marcam: ${pct(r.btts)}")
            }}
        }
        Text("As percentagens são probabilidades do modelo, não garantias de resultado.",style=MaterialTheme.typography.bodySmall)
    }
}
