package com.futbolmind.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

data class EvaluationRun(val checked: Int, val evaluated: Int)

class EvaluationClient(private val baseUrl: String) {
    private val client = OkHttpClient()

    suspend fun autoEvaluate(): EvaluationRun = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("$baseUrl/api/predictions/auto-evaluate")
            .post(okhttp3.RequestBody.create(null, ByteArray(0)))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            val root = org.json.JSONObject(response.body!!.string())
            EvaluationRun(root.optInt("checked"), root.optInt("evaluated"))
        }
    }
}
