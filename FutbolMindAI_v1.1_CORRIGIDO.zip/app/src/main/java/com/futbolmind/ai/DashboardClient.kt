package com.futbolmind.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

data class AccuracySummary(
    val evaluated: Int,
    val correct: Int?,
    val accuracy: Double?
)

class DashboardClient(private val baseUrl: String) {
    private val client = OkHttpClient()

    suspend fun summary(): AccuracySummary = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("$baseUrl/api/dashboard")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            val body = response.body!!.string()
            val root = org.json.JSONObject(body)
            val overall = root.optJSONObject("overall")
            AccuracySummary(
                evaluated = root.optInt("evaluated", 0),
                correct = overall?.optInt("correct"),
                accuracy = overall?.optDouble("accuracy")
            )
        }
    }
}
